package test_ETC_FRA;


/*
 * rtiSimple1516e.java
 *
 * Created on October 20, 2010, 11:03 AM
 */


import hla.rti1516e.AttributeHandle;
import hla.rti1516e.AttributeHandleSet;
import hla.rti1516e.AttributeHandleSetFactory;
import hla.rti1516e.AttributeHandleValueMap;
import hla.rti1516e.AttributeHandleValueMapFactory;
import hla.rti1516e.CallbackModel;
import hla.rti1516e.FederateAmbassador;
import hla.rti1516e.FederateHandle;
import hla.rti1516e.FederateHandleSaveStatusPair;
import hla.rti1516e.FederateRestoreStatus;
import hla.rti1516e.InteractionClassHandle;
import hla.rti1516e.LogicalTime;
import hla.rti1516e.MessageRetractionHandle;
import hla.rti1516e.NullFederateAmbassador;
import hla.rti1516e.ObjectClassHandle;
import hla.rti1516e.ObjectInstanceHandle;
import hla.rti1516e.OrderType;
import hla.rti1516e.ParameterHandle;
import hla.rti1516e.ParameterHandleValueMap;
import hla.rti1516e.ParameterHandleValueMapFactory;
import hla.rti1516e.RTIambassador;
import hla.rti1516e.ResignAction;
import hla.rti1516e.RestoreFailureReason;
import hla.rti1516e.RtiFactory;
import hla.rti1516e.RtiFactoryFactory;
import hla.rti1516e.SaveFailureReason;
import hla.rti1516e.TransportationTypeHandle;
import hla.rti1516e.exceptions.FederateInternalError;
import hla.rti1516e.exceptions.FederateNotExecutionMember;
import hla.rti1516e.exceptions.FederationExecutionAlreadyExists;
import hla.rti1516e.exceptions.FederationExecutionDoesNotExist;
import hla.rti1516e.exceptions.NotConnected;
import hla.rti1516e.exceptions.RTIexception;
import hla.rti1516e.exceptions.RTIinternalError;

import java.io.File;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Vector;


/**
 * simple test federate for evolved java bindings
 * code ported from rtiSimple1516e
 * @author  amerrill
 */
public class rtiSimple4etcFra {
    
	enum RestoreStatus
	{
	  NO_RESTORE_IN_PROGRESS,
	  FEDERATE_RESTORE_REQUEST_PENDING,
	  FEDERATE_WAITING_FOR_RESTORE_TO_BEGIN,
	  FEDERATE_PREPARED_TO_RESTORE,
	  FEDERATE_RESTORING,
	  FEDERATE_WAITING_FOR_FEDERATION_TO_RESTORE
	};
	
	enum SaveStatus
	{
	  NO_SAVE_IN_PROGRESS,
	  FEDERATE_INSTRUCTED_TO_SAVE,
	  FEDERATE_SAVING,
	  FEDERATE_WAITING_FOR_FEDERATION_TO_SAVE
	}

   
	/** Creates a new instance of rtiSimple1516e */
	public rtiSimple4etcFra() throws RTIinternalError
	{
		myFederationName = "FEDERATION_TEST";
        myFederateType   = "TestFederate";
        myFederateName   = "TestFederate";
        myFddFileName    = "MAKsimple1516e.xml";
        myFedAmbData     = new TalkAmbData();
		myClassName		 = "BaseEntity";
		myInterClassName = "WeaponFire";
		
		myCallQuit 		 = false;
		myCallSave 		 = false;
		myCallRestore	 = false;
        
        // Create the RTI Ambassador
        System.out.println( "Running 1516E Federate: rtiSimple1516e" );
        myFedAmb = new SimpleFederateAmbassador( myFedAmbData );
        
        RtiFactory factory = RtiFactoryFactory.getRtiFactory();
        System.out.println( "Using HLA Implementation: " + factory.rtiName() + " version: " + factory.rtiVersion() );
        
        System.out.println("pre rti amb");
        myRtiAmb = factory.getRtiAmbassador();
        System.out.println("post rti amb");
	}
	
    /**
     * Simple data structure to provide communication between the main() and
     * the FederateAmbassador.
     */
    public class TalkAmbData {
        public TalkAmbData() {
			myReceivedInitiateFederateSave = false;
			myReceivedFederationSaved = false;
			myReceivedFederationNotSaved = false;
			myReceivedFederationSaveStatusResponse = false;
			mySaveLabel = "";

			myReceivedRequestFederationRestoreSucceeded = false;
			myReceivedRequestFederationRestoreFailed = false;
			myReceivedFederationRestoreBegun = false;
			myReceivedInitiateFederateRestore = false;
			myReceivedFederationRestored = false;
			myReceivedFederationNotRestored = false;
			myReceivedFederationRestoreStatusResponse = false;
			myFederateHandleRestoreStatus = new Vector<FederateRestoreStatus>();
			myFederateHandleSaveStatus = new Vector<FederateHandleSaveStatusPair>();
		
            myNameReservationReturned = false;
            myNameReservationSucceeded = false;
            
            myObjectHandleToClassNameMap = new HashMap<ObjectClassHandle, String>();
            myObjectClassNameToHandleMap = new HashMap<Object, Object>();
            myObjectHandleToInstanceNameMap = new HashMap<ObjectInstanceHandle, String>();
            myObjectInstanceNameToHandleMap = new HashMap<String, ObjectInstanceHandle>();
            myAttributeNameToHandleMap = new HashMap<Object, Object>();
            myInteractionClassHandleToClassNameMap = new HashMap<InteractionClassHandle, String>();
            myInteractionClassNameToHandleMap = new HashMap<Object, Object>();
            myParameterNameToHandleMap = new HashMap<Object, Object>();
        }
		
		public boolean myReceivedInitiateFederateSave;
		public boolean myReceivedFederationSaved;
		public boolean myReceivedFederationNotSaved;
		public boolean myReceivedFederationSaveStatusResponse;
		public String mySaveLabel;
		public SaveFailureReason mySaveFailureReason;
		public Vector<FederateHandleSaveStatusPair> myFederateHandleSaveStatus;

		public boolean myReceivedRequestFederationRestoreSucceeded;
		public boolean myReceivedRequestFederationRestoreFailed;
		public boolean myReceivedFederationRestoreBegun;
		public boolean myReceivedInitiateFederateRestore;
		public boolean myReceivedFederationRestored;
		public boolean myReceivedFederationNotRestored;
		public boolean myReceivedFederationRestoreStatusResponse;
		public String myRestoreLabel;
		public FederateHandle myRestoreFederateHandle;
		public RestoreFailureReason myRestoreFailureReason;
		public Vector<FederateRestoreStatus> myFederateHandleRestoreStatus; // FederateRestoreStatus

		public boolean myNameReservationReturned;
		public boolean myNameReservationSucceeded;
		public HashMap<ObjectClassHandle, String> myObjectHandleToClassNameMap;
		public HashMap<Object, Object> myObjectClassNameToHandleMap;
		public HashMap<ObjectInstanceHandle, String> myObjectHandleToInstanceNameMap;
		public HashMap<String, ObjectInstanceHandle> myObjectInstanceNameToHandleMap;
		public HashMap<Object, Object> myAttributeNameToHandleMap;
		public HashMap<InteractionClassHandle, String> myInteractionClassHandleToClassNameMap;
		public HashMap<Object, Object> myInteractionClassNameToHandleMap;
		public HashMap<Object, Object> myParameterNameToHandleMap;
    }
    
    /**
     * A basic Federate Ambassador implementation
     */
    public class SimpleFederateAmbassador extends NullFederateAmbassador {
        SimpleFederateAmbassador( TalkAmbData sharedData ) {
            mySharedData = sharedData;
        }
        		
        public void printAttributeHandleValueMap( AttributeHandleValueMap theAttributes ) {
            System.out.println( theAttributes.toString() );
            for ( Iterator<AttributeHandle> it = theAttributes.keySet().iterator(); it.hasNext(); ) {
                AttributeHandle key = it.next();
                byte [] value = (byte []) theAttributes.get( key );
                System.out.println( "Handle: " + key.toString() );
                String valueString = new String( value );
                System.out.println( "Value:  " + valueString );
            }
        }
        
        public void printParameterHandleValueMap( ParameterHandleValueMap theParameters ) {
            System.out.println( theParameters.toString() );
            for ( Iterator<ParameterHandle> it = theParameters.keySet().iterator(); it.hasNext(); ) {
                ParameterHandle key = it.next();
                byte [] value = (byte []) theParameters.get( key );
                System.out.println( "Handle: " + key.toString() );
                String valueString = new String( value );
                System.out.println( "Value:  " + valueString );
            }
        }
        
        public void discoverObjectInstance(
        ObjectInstanceHandle theObject, ObjectClassHandle theObjectClass, String objectName)
        throws FederateInternalError {
            System.out.println( "................................." );
            System.out.println( "Discovered object: " + objectName + " of class: " + theObjectClass + " with handle: " + theObject );
            mySharedData.myObjectInstanceNameToHandleMap.put( objectName, theObject );
            System.out.println( "................................." );
        }
		
		public void discoverObjectInstance(
        ObjectInstanceHandle theObject, ObjectClassHandle theObjectClass, String objectName, FederateHandle producingFederate)
        throws FederateInternalError {
            System.out.println( "................................." );
            System.out.println( "Discovered object: " + objectName + " of class: " + theObjectClass + " with handle: " + theObject + " - producing Federate: " + producingFederate.toString() );
            mySharedData.myObjectInstanceNameToHandleMap.put( objectName, theObject );
            System.out.println( "................................." );
        }
        
        public void objectInstanceNameReservationSucceeded(String objectName)
        throws FederateInternalError {
            System.out.println( "................................." );
            System.out.println( "Object Name Reservation Succeeded" );
            mySharedData.myNameReservationReturned = true;
            mySharedData.myNameReservationSucceeded = true;
            System.out.println( "................................." );
        }
        
        public void objectInstanceNameReservationFailed(String objectName)
        throws FederateInternalError {
            System.out.println( "................................." );
            System.out.println( "Object Name Reservation Failed" );
            mySharedData.myNameReservationReturned = true;
            mySharedData.myNameReservationSucceeded = false;
            System.out.println( "................................." );
        }
		
		public void reflectAttributeValues(ObjectInstanceHandle theObject,
                                      AttributeHandleValueMap theAttributes,
                                      byte[] userSuppliedTag,
                                      OrderType sentOrdering,
                                      TransportationTypeHandle theTransport,
                                      SupplementalReflectInfo reflectInfo)
      throws FederateInternalError {
            System.out.println( "................................." );
            System.out.println( "Reflected Update for object: " + theObject );
            System.out.println( "Sent Order: " + sentOrdering.toString() );
            System.out.println( "Transport Type: " + theTransport.toString() );
            System.out.print( "Tag Value:" );
            String tagString = new String( userSuppliedTag );
            System.out.println( tagString );
            System.out.println( "Attribute Data: ");
            printAttributeHandleValueMap( theAttributes );
            System.out.println( "................................." );
		}

    	@SuppressWarnings("rawtypes")
		public void reflectAttributeValues(
        ObjectInstanceHandle theObject,
        AttributeHandleValueMap theAttributes,
        byte[] userSuppliedTag,
        OrderType sentOrdering,
        TransportationTypeHandle theTransport,
		LogicalTime	theTime,
		OrderType receivedOrdering,
		SupplementalReflectInfo reflectInfo )
        throws FederateInternalError {
            System.out.println( "................................." );
            System.out.println( "Reflected Update for object: " + theObject );
            System.out.println( "Sent Order: " + sentOrdering.toString() );
            System.out.println( "Transport Type: " + theTransport.toString() );
            System.out.print( "Tag Value:" );
            String tagString = new String( userSuppliedTag );
            System.out.println( tagString );
            System.out.println( "Attribute Data: ");
            printAttributeHandleValueMap( theAttributes );
			System.out.println( "theTime: " + theTime.toString() );
			System.out.println( "receivedOrdering: " + receivedOrdering.toString() );
            System.out.println( "................................." );
        }
        
        public void removeObjectInstance(
        ObjectInstanceHandle theObject, byte[] userSuppliedTag, OrderType sentOrdering, SupplementalRemoveInfo removeInfo )
        throws FederateInternalError {
            System.out.println( "................................." );
            System.out.println( "Removed Object Instance: " + theObject );
            System.out.println( "Tag Value: " + userSuppliedTag.toString() );
            System.out.println( "Sent Order: " + sentOrdering.toString() );
            mySharedData.myObjectInstanceNameToHandleMap.values().remove( theObject );
            System.out.println( "................................." );
        }
        
		@SuppressWarnings("rawtypes")
		public void removeObjectInstance(
        ObjectInstanceHandle theObject, byte[] userSuppliedTag, OrderType sentOrdering, LogicalTime theTime, OrderType receivedOrdering, SupplementalRemoveInfo removeInfo )
        throws FederateInternalError {
            System.out.println( "................................." );
            System.out.println( "Removed Object Instance: " + theObject );
            System.out.println( "Tag Value: " + userSuppliedTag.toString() );
            System.out.println( "Sent Order: " + sentOrdering.toString() );
			System.out.println( "the time: " + theTime.toString() );
			System.out.println( "received ordering: " + receivedOrdering.toString() );
            mySharedData.myObjectInstanceNameToHandleMap.values().remove( theObject );
            System.out.println( "................................." );
        }
		
		@SuppressWarnings("rawtypes")
		public void removeObjectInstance(
        ObjectInstanceHandle theObject, byte[] userSuppliedTag, OrderType sentOrdering, LogicalTime theTime, OrderType receivedOrdering, MessageRetractionHandle retractionHandle, SupplementalRemoveInfo removeInfo )
        throws FederateInternalError {
            System.out.println( "................................." );
            System.out.println( "Removed Object Instance: " + theObject );
            System.out.println( "Tag Value: " + userSuppliedTag.toString() );
            System.out.println( "Sent Order: " + sentOrdering.toString() );
			System.out.println( "Message Retraction Handle: " + retractionHandle.toString() );
            mySharedData.myObjectInstanceNameToHandleMap.values().remove( theObject );
            System.out.println( "................................." );
        }
        
        public void receiveInteraction (
          InteractionClassHandle      interactionClass,
          ParameterHandleValueMap     theParameters,
          byte[]                      userSuppliedTag,
          OrderType                   sentOrdering,
          TransportationTypeHandle    theTransport,
		  SupplementalReceiveInfo 	  receiveInfo )
        throws
          FederateInternalError {
            System.out.println( "................................." );
            System.out.println( "Received Interaction: " + interactionClass );
            System.out.println( "Sent Order: " + sentOrdering.toString() );
            System.out.println( "Transport Type: " + theTransport.toString() );
            System.out.print( "Tag Value:" );
            String tagString = new String( userSuppliedTag );
            System.out.println( tagString );
            System.out.println( "Parameter Data: ");
            printParameterHandleValueMap( theParameters );
            System.out.println( "................................." );
        }

		 @SuppressWarnings("rawtypes")
		public void receiveInteraction (
          InteractionClassHandle      interactionClass,
          ParameterHandleValueMap     theParameters,
          byte[]                      userSuppliedTag,
          OrderType                   sentOrdering,
          TransportationTypeHandle    theTransport,
		  LogicalTime 				  theTime,
          OrderType 				  receivedOrdering,
		  SupplementalReceiveInfo 	  receiveInfo )
        throws
          FederateInternalError {
            System.out.println( "................................." );
            System.out.println( "Received Interaction: " + interactionClass );
            System.out.println( "Sent Order: " + sentOrdering.toString() );
            System.out.println( "Transport Type: " + theTransport.toString() );
            System.out.print( "Tag Value:" );
            String tagString = new String( userSuppliedTag );
            System.out.println( tagString );
            System.out.println( "Parameter Data: ");
            printParameterHandleValueMap( theParameters );
			System.out.println( "the time: " + theTime.toString() );
			System.out.println( "received ordering: " + receivedOrdering.toString() );
            System.out.println( "................................." );
        }
		
		 @SuppressWarnings("rawtypes")
		public void receiveInteraction (
          InteractionClassHandle      interactionClass,
          ParameterHandleValueMap     theParameters,
          byte[]                      userSuppliedTag,
          OrderType                   sentOrdering,
          TransportationTypeHandle    theTransport,
		  LogicalTime 				  theTime,
		  OrderType 				  receivedOrdering,
		  MessageRetractionHandle 	  retractionHandle,
		  SupplementalReceiveInfo 	  receiveInfo )
        throws
          FederateInternalError {
            System.out.println( "................................." );
            System.out.println( "Received Interaction: " + interactionClass );
            System.out.println( "Sent Order: " + sentOrdering.toString() );
            System.out.println( "Transport Type: " + theTransport.toString() );
            System.out.print( "Tag Value:" );
            String tagString = new String( userSuppliedTag );
            System.out.println( tagString );
            System.out.println( "Parameter Data: ");
            printParameterHandleValueMap( theParameters );
			System.out.println( "the time: " + theTime.toString() );
			System.out.println( "received ordering: " + receivedOrdering.toString() );
			System.out.println( "Message Retraction Handle: " + retractionHandle.toString() );
            System.out.println( "................................." );
        }
		
		
		// SAVE | RESTORE CALLBACKS
		public void initiateFederateSave( String label )
		throws 
			FederateInternalError
		{
			System.out.println( "................................." );
			System.out.println( "initiateFederateSave: " + label );
			mySharedData.myReceivedInitiateFederateSave = true;
			mySharedData.mySaveLabel = label;
			System.out.println( "................................." );
		}

		public void federationSaved()
		throws
			FederateInternalError
		{
			System.out.println( "................................." );
			System.out.println( "federationSaved " );
			mySharedData.myReceivedFederationSaved = true;
			System.out.println( "................................." );
		}

		public void federationNotSaved( SaveFailureReason theSaveFailureReason )
		throws
			FederateInternalError
		{
			System.out.println( "................................." );
			System.out.println( "federationNotSaved: " );
			switch (theSaveFailureReason)
			{
			case RTI_UNABLE_TO_SAVE:
			  System.out.println( "RTI_UNABLE_TO_SAVE" );
			  break;
			case FEDERATE_REPORTED_FAILURE_DURING_SAVE:
			  System.out.println( "FEDERATE_REPORTED_FAILURE_DURING_SAVE" );
			  break;
			case FEDERATE_RESIGNED_DURING_SAVE:
			  System.out.println( "FEDERATE_RESIGNED_DURING_SAVE" );
			  break;
			case RTI_DETECTED_FAILURE_DURING_SAVE:
			  System.out.println( "RTI_DETECTED_FAILURE_DURING_SAVE" );
			  break;
			case SAVE_TIME_CANNOT_BE_HONORED:
			  System.out.println( "SAVE_TIME_CANNOT_BE_HONORED" );
			  break;
			case SAVE_ABORTED:
			  System.out.println( "SAVE_ABORTED" );
			  break;
			default:
			  System.out.println( "UNKNOWN" );
			  break;
			}
			mySharedData.mySaveFailureReason = theSaveFailureReason;
			mySharedData.myReceivedFederationNotSaved = true;
			System.out.println( "................................." );
		}

		public void federationSaveStatusResponse( FederateHandleSaveStatusPair[] theFederateStatusVector )
		throws
			FederateInternalError
		{
			System.out.println( "................................." );
			System.out.println( "federationSaveStatusResponse" );
			mySharedData.myReceivedFederationSaveStatusResponse = true;
			//mySharedData.myFederateHandleSaveStatus = theFederateStatusVector;
			for( int i = 0; i < theFederateStatusVector.length; i++ )
			{
				mySharedData.myFederateHandleSaveStatus.add(i, theFederateStatusVector[i] );
			}
			System.out.println( "................................." );
		}


		public void requestFederationRestoreSucceeded(String label)
		throws
			FederateInternalError
		{
			System.out.println( "................................." );
			System.out.println( "requestFederationRestoreSucceeded " + label );
			mySharedData.myReceivedRequestFederationRestoreSucceeded = true;
			mySharedData.myRestoreLabel = label;
			System.out.println( "................................." );
		}

		public void requestFederationRestoreFailed( String label)
		throws 
			FederateInternalError
		{
			System.out.println( "................................." );
			System.out.println( "requestFederationRestoreFailed " + label );
			mySharedData.myReceivedRequestFederationRestoreFailed = true;
			mySharedData.myRestoreLabel = label;
			System.out.println( "................................." );
		}

		public void federationRestoreBegun()
		throws
			FederateInternalError
		{
			System.out.println( "................................." );
			System.out.println( "federationRestoreBegun" );
			mySharedData.myReceivedFederationRestoreBegun = true;
			System.out.println( "................................." );
		}

		public void initiateFederateRestore(
			  String label,
			  String federateName,
			  FederateHandle federateHandle)
		throws
			FederateInternalError
		{
			System.out.println( "................................." );
			System.out.println( "initiateFederateRestore " + label + " " + federateName + " " + federateHandle.toString() );
			mySharedData.myReceivedInitiateFederateRestore = true;
			mySharedData.myRestoreLabel = label;
			mySharedData.myRestoreFederateHandle = federateHandle;
			System.out.println( "................................." );
		}

		public void federationRestored()
		throws
			FederateInternalError
		{
			System.out.println( "................................." );
			System.out.println( "federationRestored" );
			mySharedData.myReceivedFederationRestored = true;
			System.out.println( "................................." );
		}

		public void federationNotRestored(RestoreFailureReason theRestoreFailureReason)
		throws
			FederateInternalError
		{
			System.out.println( "................................." );
			System.out.println( "federationNotRestored: " );
			switch (theRestoreFailureReason)
			{
			case RTI_UNABLE_TO_RESTORE:
			  System.out.println("RTI_UNABLE_TO_RESTORE");
			  break;
			case FEDERATE_REPORTED_FAILURE_DURING_RESTORE:
			  System.out.println("FEDERATE_REPORTED_FAILURE_DURING_RESTORE");
			  break;
			case FEDERATE_RESIGNED_DURING_RESTORE:
			  System.out.println("FEDERATE_RESIGNED_DURING_RESTORE");
			  break;
			case RTI_DETECTED_FAILURE_DURING_RESTORE:
			  System.out.println("RTI_DETECTED_FAILURE_DURING_RESTORE");
			  break;
			case RESTORE_ABORTED:
			  System.out.println("RESTORE_ABORTED");
			  break;
			default:
			  System.out.println("Unknown reason");
			  break;
			}
			mySharedData.myReceivedFederationNotRestored = true;
			mySharedData.myRestoreFailureReason = theRestoreFailureReason;
			System.out.println( "................................." );
		}

		public void federationRestoreStatusResponse( FederateRestoreStatus[] theFederateRestoreStatusVector )
		throws
			FederateInternalError
		{
			System.out.println( "................................." );
			System.out.println("federationRestoreStatusResponse" );
			mySharedData.myReceivedFederationRestoreStatusResponse = true;
			//mySharedData.myFederateHandleRestoreStatus = theFederateRestoreStatusVector;
			for( int i = 0; i < theFederateRestoreStatusVector.length; i++ )
			{
				mySharedData.myFederateHandleRestoreStatus.add( i , theFederateRestoreStatusVector[i] );
			}
			System.out.println( "................................." );
		}
       
        
        
        TalkAmbData mySharedData;
    }
    
    public class AttrNameHandleMap
	{
		AttrNameHandleMap()
		{
			myName = "";
			myHandle = null;
		}
		
		public void name( String value ) { myName = value; }
		public void handle( AttributeHandle value ) { myHandle = value; }
		
		public String name() { return myName; }
		public AttributeHandle handle() { return myHandle; }
		
		private String myName;
		private AttributeHandle myHandle;
	}
	
	public class ParamNameHandleMap
	{
		ParamNameHandleMap()
		{
			myName = "";
			myHandle = null;
		}
		
		public void name( String value ) { myName = value; }
		public void handle( ParameterHandle value ) { myHandle = value; }
		
		public String name() { return myName; }
		public ParameterHandle handle() { return myHandle; }
		
		private String myName;
		private ParameterHandle myHandle;
	}

	public void connect() throws RTIexception
	{
		try
		{
			myRtiAmb.connect( myFedAmb, CallbackModel.HLA_EVOKED );
		}
		catch( RTIexception  ex )
		{
			System.out.println("RTI Exception: " + ex.getClass().toString() + " : " + ex.toString() );
			throw ex;
		}
		
		System.out.println("Connected.");
	}

	public void createFedEx() throws RTIexception, java.net.MalformedURLException {
        System.out.println("----------------------------------");
        System.out.println("Creating Federation: " + myFederationName + " using FDD file: " + myFddFileName );
        try {
            File myFddFile = new File(myFddFileName);
            myRtiAmb.createFederationExecution( myFederationName, myFddFile.toURI().toURL() );
            
        } catch ( FederationExecutionAlreadyExists ex ) {
            System.out.println( "Caught FederationAlreadyExists exception: " + ex.toString() );
        } catch ( RTIexception ex ) {
            System.out.println( "Could not create Federation: " + ex.getClass().toString() + " : " + ex.toString() );
            throw ex;
        }
        System.out.println("Federation Created.");
        System.out.println("----------------------------------");
    }
    
    public void joinFedEx() throws RTIexception, java.net.MalformedURLException {
        System.out.println("----------------------------------");
        System.out.println("Joining Federation: " + myFederationName );
        
        
        boolean joined   = false;
        final long maxTries = 10;
        long       numTries = 0;
        while ( !joined && ( numTries++ < maxTries )) {
            try {
                System.out.println("type = " + myFederateType );
				System.out.println("name = " + myFederationName );
                myFederateHandle = myRtiAmb.joinFederationExecution( myFederateName,myFederateType, myFederationName );
                joined = true;
                
            } catch ( FederationExecutionDoesNotExist ex ) {
                System.out.println( "Try: " + numTries + " of " + maxTries );
                System.out.println( "Caught FederationExecutionDoesNotExist exception: " + ex.toString() );
                if ( numTries == maxTries ) {
                    System.out.println("Failed to Join Federation (timed out).");
                    throw ex;
                }
            } catch ( RTIexception ex ) {
                System.out.println( "Could not create Federation: " + ex.getClass().toString() + " : " + ex.toString() );
                throw ex;
            }
            
            evokeCallbacks( 0.1, 0.2 );
        }
        
        System.out.println("Joined Federation.");
        System.out.println("----------------------------------");
    }
    
    public void resignAndDestroyFedEx() throws RTIexception {
        System.out.println("----------------------------------");
        System.out.println("Resigning from federation: " + myFederationName );
        
        // Simply re-throw exceptions ( we can't do anything about them now... )
        myRtiAmb.resignFederationExecution( ResignAction.DELETE_OBJECTS );
        System.out.println("Resigned from federation.");
        
        myRtiAmb.destroyFederationExecution( myFederationName );
        System.out.println("Destroyed federation.");
		
		myRtiAmb.disconnect();
		System.out.println("Disconnected.");
        System.out.println("----------------------------------");
    }
	
	public void queryFederationSaveStatus() throws RTIexception
	{
		System.out.println( "Query save status." );
		
		myRtiAmb.queryFederationSaveStatus();
		
		int count = 0;
		while( ( count++ < 100 ) && ( !myFedAmbData.myReceivedFederationSaveStatusResponse ) )
		{
			evokeCallbacks( 0.1, 0.2 );
		}
		
		if( !myFedAmbData.myReceivedFederationSaveStatusResponse )
		{
			System.out.println( "Timed out waiting for status response" );
			return;
		}
		else
		{
			for( Iterator<FederateHandleSaveStatusPair> it = myFedAmbData.myFederateHandleSaveStatus.iterator(); it.hasNext(); )
			{
				FederateHandleSaveStatusPair statusPair = it.next();
				System.out.println( "Status Federate: " + statusPair.handle.toString() + " : " + statusPair.status.toString() );
				switch( statusPair.status )
				{
					case NO_SAVE_IN_PROGRESS:
					{
						System.out.println("NO_SAVE_IN_PROGRESS");
						break;
					}
					case FEDERATE_INSTRUCTED_TO_SAVE:
					{
						System.out.println("FEDERATE_INSTRUCTED_TO_SAVE");
						break;
					}
					case FEDERATE_SAVING:
					{
						System.out.println("FEDERATE_SAVING");
						break;
					}
					case FEDERATE_WAITING_FOR_FEDERATION_TO_SAVE:
					{
						System.out.println("FEDERATE_WAITING_FOR_FEDERATION_TO_SAVE");
						break;
					}
					default:
					{
						System.out.println("UNKNOWN");
						break;
					}
				}
			}
		}
	}
    
	public boolean requestFederationSave( String label ) throws RTIexception
	{
		boolean saveOk = true;
		int count = 0;
		
		// Turn the signals off
		myFedAmbData.myReceivedInitiateFederateSave = 
		myFedAmbData.myReceivedFederationSaved = 
		myFedAmbData.myReceivedFederationNotSaved = 
		myFedAmbData.myReceivedFederationSaveStatusResponse = false;
		
		System.out.println( "Request federation save with label " + label );
		
		// Request the save and wait for the signal that the save has been initiated
		// or that the federation has not saved ( could be that some other federate 
		// resigns during save )
		myRtiAmb.requestFederationSave( label );
		
		while( 	( count++ < 100 )
				&& !myFedAmbData.myReceivedInitiateFederateSave
				&& !myFedAmbData.myReceivedFederationNotSaved )
		{
			evokeCallbacks( 0.1, 0.2 );
		}
		
		if( !myFedAmbData.myReceivedInitiateFederateSave )
		{
			saveOk = false;
			if( !myFedAmbData.myReceivedFederationNotSaved )
			{
				System.out.println( "Timed out waiting for initiate federate save" );
				this.queryFederationSaveStatus();
			}
		}
		return saveOk;
	}
	
	public boolean waitForFederationSaved() throws RTIexception
	{
		boolean saveOk = true;
		int count = 0;
		
		// wait until the RTI signals that the entire federation completed the save
		while( 	( count++ < 100 )
				&& !myFedAmbData.myReceivedFederationNotSaved
				&& !myFedAmbData.myReceivedFederationSaved )
		{
			evokeCallbacks( 0.1, 0.2 );
		}
		
		if( !myFedAmbData.myReceivedFederationSaved )
		{
			saveOk = false;
			if( !myFedAmbData.myReceivedFederationNotSaved )
			{
				System.out.println( "Timed out waiting for federation saved" );
				this.queryFederationSaveStatus();
			}
		}
		return saveOk;
	}
	
	public boolean saveFederation( String label, boolean performRequest ) throws RTIexception
	{
		boolean saveOk = true;
		
		try
		{
			if( performRequest )
			{
				saveOk = requestFederationSave( label );
			}
			
			if( myFedAmbData.myReceivedInitiateFederateSave )
			{
				// At this point, the save has been initiated
				// and the federate cannot invoke any other calls except
				// to complete the save ( or resign ). It signals to the RTI that
				// it will begin saving its own local state
				
				System.out.println( "Federate save begun" );
				myRtiAmb.federateSaveBegun();
				
				// Here the federate would save its own state including any context
				// information relating to the RTI
				// (ie. what classes are published and subscribed 
				// object intance handles for registered and discovered objects, etc...
				
				// Once the federate saves it's own data, it signals to the RTI that it's 
				// save is complete.
				System.out.println( "Federate save complete" );
				myRtiAmb.federateSaveComplete();
				
				// wait until the RTI signals that the entire federation completed the save
				saveOk = this.waitForFederationSaved();
			}
		}
		catch( RTIexception  ex )
		{
			System.out.println( "RTI Exception: " + ex.toString() );
			System.out.println( "Could not save federation : " + label );
			saveOk = false;
			throw ex;
		}
		catch( Exception  ex )
		{
			System.out.println( "Standard exception: " + ex.toString() );
			System.out.println( "Could not save federation : " + label );
			saveOk = false;
		}
		
		// Turn the signals off
		myFedAmbData.myReceivedInitiateFederateSave =
		myFedAmbData.myReceivedFederationSaved = 
		myFedAmbData.myReceivedFederationNotSaved =
		myFedAmbData.myReceivedFederationSaveStatusResponse = false;
		
		return saveOk;
	}
	
	public void queryRestoreStatus() throws RTIexception
	{
		// Check the status
		myRtiAmb.queryFederationRestoreStatus();
		
		int count = 0;
		while( 	( count++ < 100 )
				&& !myFedAmbData.myReceivedFederationRestoreStatusResponse )
		{
			evokeCallbacks( 0.1, 0.2 );
		}
		
		if( !myFedAmbData.myReceivedFederationRestoreStatusResponse )
		{
			System.out.println( "Timed out waiting for restore status" );
		}
		else
		{
			for ( Iterator<FederateRestoreStatus> it = myFedAmbData.myFederateHandleRestoreStatus.iterator(); it.hasNext(); )
			{
				FederateRestoreStatus restoreStatus = it.next();
				System.out.println( "Status federate " + restoreStatus.preRestoreHandle.toString() + " : " + restoreStatus.status.toString() );
				switch (restoreStatus.status)
				{
					case NO_RESTORE_IN_PROGRESS:
					{
						System.out.println( "NO_RESTORE_IN_PROGRESS" );
						break;
					}
					case FEDERATE_RESTORE_REQUEST_PENDING:
					{
						System.out.println("FEDERATE_RESTORE_REQUEST_PENDING");
						break;
					}
					case FEDERATE_WAITING_FOR_RESTORE_TO_BEGIN:
					{
						System.out.println("FEDERATE_WAITING_FOR_RESTORE_TO_BEGIN");
						break;
					}
					case FEDERATE_PREPARED_TO_RESTORE:
					{
						System.out.println("FEDERATE_PREPARED_TO_RESTORE");
						break;
					}
					case FEDERATE_RESTORING:
					{
						System.out.println("FEDERATE_RESTORING");
						break;
					}
					case FEDERATE_WAITING_FOR_FEDERATION_TO_RESTORE:
					{
						System.out.println("FEDERATE_WAITING_FOR_FEDERATION_TO_RESTORE");
						break;
					}
					default:
					{
						System.out.println("UNKNOWN");
						break;
					}
				}
			}
		}
	}
	
	public boolean requestFederationRestore( String label ) throws RTIexception
	{
		int count = 0;
		boolean restoreOk = true;
		
		System.out.println( "Request federation restore with label " + label );
		
		// turn the signals off
		myFedAmbData.myReceivedRequestFederationRestoreSucceeded =
		myFedAmbData.myReceivedRequestFederationRestoreFailed =
		myFedAmbData.myReceivedFederationRestoreBegun =
		myFedAmbData.myReceivedInitiateFederateRestore =
		myFedAmbData.myReceivedFederationRestored =
		myFedAmbData.myReceivedFederationNotRestored =
		myFedAmbData.myReceivedFederationRestoreStatusResponse = false;
		myFedAmbData.myFederateHandleRestoreStatus.clear();
		
		myRtiAmb.requestFederationRestore( label );
		while( 	( count++ < 100 )
				&& !myFedAmbData.myReceivedRequestFederationRestoreSucceeded
				&& !myFedAmbData.myReceivedRequestFederationRestoreFailed )
		{
			evokeCallbacks( 0.1, 0.2 );
		}
		
		if( !myFedAmbData.myReceivedRequestFederationRestoreSucceeded )
		{
			restoreOk = false;
			if( !myFedAmbData.myReceivedRequestFederationRestoreFailed )
			{
				System.out.println( "Timed out waiting for request federation restore succeeded." );
				queryRestoreStatus();
			}
		}
		return restoreOk;
	}
	
	public boolean waitForRestoreBegun() throws RTIexception
	{
		boolean restoreOk = true;

		// wait for the restore
		System.out.println( "Wait for restore begun." );
		int count = 0;
		
		while( 	( count++ < 100 )
				&& !myFedAmbData.myReceivedFederationRestoreBegun
				&& !myFedAmbData.myReceivedFederationNotRestored )
		{
			evokeCallbacks( 0.1, 0.2 );
		}
		
		if( !myFedAmbData.myReceivedFederationRestoreBegun )
		{
			restoreOk = false;
			if( !myFedAmbData.myReceivedFederationNotRestored )
			{
				System.out.println( "Timed out waiting for federation restore begun." );
				queryRestoreStatus();
			}
		}
		return restoreOk;
	}
	
	public boolean waitForInitiateRestore() throws RTIexception
	{
		boolean restoreOk = true;
		
		// wait for initiate restore
		System.out.println( "Wait for initiate restore." );
		
		int count = 0;
		while( 	( count++ < 100 )
				&& !myFedAmbData.myReceivedInitiateFederateRestore
				&& !myFedAmbData.myReceivedFederationNotRestored )
		{
			evokeCallbacks( 0.1, 0.2 );
		}
		
		if( myFedAmbData.myReceivedFederationNotRestored )
		{
			restoreOk = false;
		}
		else if( !myFedAmbData.myReceivedInitiateFederateRestore )
		{
			restoreOk = false;
			System.out.println( "Timed out waiting for initiate federate restore." );
			queryRestoreStatus();
		}
		else if( myFedAmbData.myRestoreFederateHandle.equals( myFederateHandle ) == false )
		{
			// In general, a federate must be able to restore any saved state of
			// a federate of the same type. Even if a federate submits 
			// a unique federate type string during join, the current federate
			// and object handles may not match those being restored.
			// This simplistic federate implementation cannot handle the case where
			// the federate and object handles are different
			System.out.println( "Restore initiated with handle " + myFedAmbData.myRestoreFederateHandle.toString() );
			System.out.println( " does not match current handle " + myFederateHandle.toString() );
			System.out.println( "Unable to complete restore." );
			
			restoreOk = false;
			
			// will revert to state before restore was begun
			myRtiAmb.federateRestoreNotComplete();
			
			count = 0;
			while( 	( count++ < 100 )
					&& !myFedAmbData.myReceivedFederationNotRestored )
			{
				evokeCallbacks( 0.1, 0.2 );
			}
			
			if( !myFedAmbData.myReceivedFederationNotRestored )
			{
				System.out.println( "Timed out waiting for federation not restored." );
				queryRestoreStatus();
			}
		}
		return restoreOk;
	}
	
	public boolean waitForFederationRestored() throws RTIexception
	{
		boolean restoreOk = true;
		
		// wait until the RTI signals that the entire federation completed the restore
		System.out.println( "Wait for federation restored." );
		
		int count = 0;
		while( 	( count++ < 100 )
				&& !myFedAmbData.myReceivedFederationRestored
				&& !myFedAmbData.myReceivedFederationNotRestored )
		{
			evokeCallbacks( 0.1, 0.2 );
		}
		
		if( !myFedAmbData.myReceivedFederationRestored )
		{
			restoreOk = false;
			if( !myFedAmbData.myReceivedFederationNotRestored )
			{
				System.out.println( "Timed out waiting for federation restored." );
				queryRestoreStatus();
			}
		}
		return restoreOk;
	}
	
	public boolean restoreFederation( String label, boolean performRequest ) throws RTIexception
	{
		boolean restoreOk = true;
		
		myFedAmbData.myReceivedFederationNotRestored = false;
		
		try
		{
			if( performRequest )
			{
				if( requestFederationRestore( label ) )
				{
					restoreOk = this.waitForRestoreBegun();
				}
			}
			
			if( myFedAmbData.myReceivedFederationRestoreBegun )
			{
				// At this point, the restore has begun 
				// and the federate cannot invoke any other calls except
				// to complete the restore( or resign ). It waits for the 
				// initiate restore to begin restoring it's local state.
				
				if( restoreOk = waitForInitiateRestore() )
				{
					// Here the federate would restore it's own state including any context
					// information relating to the RTI
					// (i.e. what classes are published and subscribed
					// object instance handles for registerdd and discovered objects, etc...
					
					// Once the federate restores it's own data, it signals to the RTI that it's 
					// restore is complete.
					System.out.println( "Federate restore complete." );
					myRtiAmb.federateRestoreComplete();
					
					// If the federate was unable to restore it's state, it would respondr with 
					// federateRestoreNotComplete
					
					// not wait for remaining federation to be restored
					restoreOk = this.waitForFederationRestored();
				}
			}
		}
		catch( FederateInternalError ex )
		{
			System.out.println( "RTI Exception: " + ex.getClass().toString() + " : " + ex.toString() );
			System.out.println( "Could not restore federation " + label );
			restoreOk = false;
		}
		catch( RTIexception  ex )
		{
			System.out.println( "RTI Exception: " + ex.getClass().toString() + " : " + ex.toString() );
			System.out.println( "Could not restore federation " + label );
			restoreOk = false;
			throw ex;
		}
		catch( Exception  ex )
		{
			System.out.println( "Standard Exception: " + ex.getClass().toString() + " : " + ex.toString() );
			System.out.println( "Could not restore federation " + label );
			restoreOk = false;
		}
		
		// Turn the signals off
		myFedAmbData.myReceivedRequestFederationRestoreSucceeded =
		myFedAmbData.myReceivedRequestFederationRestoreFailed =
		myFedAmbData.myReceivedFederationRestoreBegun =
		myFedAmbData.myReceivedInitiateFederateRestore =
		myFedAmbData.myReceivedFederationRestored =
		myFedAmbData.myReceivedFederationNotRestored =
		myFedAmbData.myReceivedFederationRestoreStatusResponse = false;
		myFedAmbData.myFederateHandleRestoreStatus.clear();
		
		return restoreOk;
	}
	
    public boolean publishSubscribeAndRegisterObject() throws RTIexception 
	{		
		AttributeHandleSetFactory factory = myRtiAmb.getAttributeHandleSetFactory();
		AttributeHandleSet hSet = factory.create();
		ObjectClassHandle myClassHandle;
		// Get the object class handle
		try
		{
		System.out.println(" --- 1 --- " );
			myClassHandle = myRtiAmb.getObjectClassHandle( myClassName );
			if( myClassHandle == null )
			{
			 System.out.println( "NULL!" );
			}
			else
			{
				System.out.println( "print the handle " );
				System.out.println( myClassHandle.toString() );
			}
			System.out.println( "1.1 - name " + myClassName );
			System.out.println( "handle - " + myClassHandle.encodedLength() );
			myFedAmbData.myObjectHandleToClassNameMap.put( myClassHandle, myClassName );
			System.out.println(" --- 2 --- " );
		}
		catch( RTIexception ex )
		{
			System.out.println( "RTI Exception: " + ex.getClass().toString() + " : " + ex.toString() );
			System.out.println( "Could not get object class handle: " + myClassName );
			return false;
		}
		
		// Get the attribute handles and construct the name-handle map and 
		// attribute set
		String attrName = "";
		try
		{
			myAttrNameHandleMap = new HashMap<String, AttributeHandle>();			
			attrName = "AccelerationVector";
			myAttrNameHandleMap.put( attrName, myRtiAmb.getAttributeHandle( myClassHandle, attrName ) );
			hSet.add( (AttributeHandle)myAttrNameHandleMap.get( attrName ) );
			
			attrName = "VelocityVector"; 
			myAttrNameHandleMap.put( attrName, myRtiAmb.getAttributeHandle( myClassHandle, attrName ) );
			hSet.add( (AttributeHandle)myAttrNameHandleMap.get( attrName ) );
			
			attrName = "Orientation";
			myAttrNameHandleMap.put( attrName, myRtiAmb.getAttributeHandle( myClassHandle, attrName ) );
			hSet.add( (AttributeHandle)myAttrNameHandleMap.get( attrName ) );
			
			attrName = "DeadReckoningAlgorithm";
			myAttrNameHandleMap.put( attrName, myRtiAmb.getAttributeHandle( myClassHandle, attrName ) );
			hSet.add( (AttributeHandle)myAttrNameHandleMap.get( attrName ) );
			
			attrName = "WorldLocation";
			myAttrNameHandleMap.put( attrName, myRtiAmb.getAttributeHandle( myClassHandle, attrName ) );
			hSet.add( (AttributeHandle)myAttrNameHandleMap.get( attrName ) );		
		}
		catch( RTIexception ex )
		{
			System.out.println( "RTI Exception: " + ex.getClass().toString() + " : " + ex.toString() );
			System.out.println( "Could not get attribute handle " + attrName );
			return false;
		}
		
		// Publish and subscribe
		int publishSubscribeCount = 0;
		try
		{
		System.out.println(" --- 3 --- " );
			myRtiAmb.publishObjectClassAttributes( myClassHandle, hSet );
			evokeCallbacks( 0.1, 0.2 );
			
			publishSubscribeCount = 1;
			
			System.out.println(" --- 4 --- " );
			myRtiAmb.subscribeObjectClassAttributes( myClassHandle, hSet );
			evokeCallbacks( 0.1, 0.2 );
		}
		catch( RTIexception ex )
		{
			System.out.println( "RTI Exception: " + ex.getClass().toString() + " : " + ex.toString() );
			if( publishSubscribeCount != 0 )
				System.out.println( "Could not subscribe" );
			else
				System.out.println( "Could not publish" );
			return false;
		}

		String objectName = "javaTalk" +  + System.currentTimeMillis();

		try
		{
			myFedAmbData.myNameReservationReturned =
			myFedAmbData.myNameReservationSucceeded = false;
			
			myRtiAmb.reserveObjectInstanceName( objectName );
			int count = 0;
			while( 	( count++ < 100 )
					&& !myFedAmbData.myNameReservationReturned )
			{
				evokeCallbacks( 0.1, 0.2 );
			}
			
			System.out.println( "Name reservation -- 1 " );
			
			if( count < 100 )
			{
				System.out.println( "Name reservation -- 2 " );
				myObjectHandle = myRtiAmb.registerObjectInstance( myClassHandle, objectName );
				
				System.out.println( "Name reservation -- 3 " );
				// add the name-handle to map
				myFedAmbData.myObjectHandleToInstanceNameMap.put( myObjectHandle, 
					myRtiAmb.getObjectInstanceName( myObjectHandle ) );
				
				System.out.println( "Name reservation -- 4 " );
			}
			else
			{
				System.out.println( "Failed waiting for reserve object name " + objectName );
				return false;
			}
			evokeCallbacks( 0.1, 0.2 );
		}
		catch( RTIexception  ex )
		{
			System.out.println( "RTI Exception: " + ex.getClass().toString() + " : " + ex.toString() );
			System.out.println( "Could not Register Object: " + objectName + " with class " + myClassName );
			return false;
		}
		
		System.out.println( "Registered object " + objectName + " with class name " + myClassName );
		return true;	  
    }
    
	public boolean publishAndSubscribeInteraction() throws RTIexception 
	{
		// Get the ineraction class handle
		try
		{
			myInterClassHandle = myRtiAmb.getInteractionClassHandle( myInterClassName );
			myFedAmbData.myInteractionClassHandleToClassNameMap.put( myInterClassHandle, myInterClassName );
		}
		catch( RTIexception ex )
		{
			System.out.println( "RTI Exception: " + ex.getClass().toString() + " : " + ex.toString() );
			return false;
		}
		
		// Get the parameter handles and construct the name-handle map
		String paramName = null;
		try
		{
			myParamNameHandleMap = new HashMap<String, ParameterHandle>();
			
			paramName = "EventIdentifier";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
			paramName = "FireControlSolutionRange";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
			paramName = "FireMissionIndex";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
			paramName = "FiringLocation";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
			paramName = "FiringObjectIdentifier";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
			paramName = "FuseType";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
			paramName = "InitialVelocityVector";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
			paramName = "MunitionObjectIdentifier";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
			paramName = "MunitionType";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
			paramName = "QuantityFired";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
			paramName = "RateOfFire";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
			paramName = "TargetObjectIdentifier";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
			paramName = "WarheadType";
			myParamNameHandleMap.put( paramName,
				myRtiAmb.getParameterHandle( myInterClassHandle, paramName ) );
		}
		catch( RTIexception ex )
		{
			System.out.println( "RTI Exception: " + ex.getClass().toString() + ex.toString() );
			System.out.println( "Could not get parameter handle " + paramName );
			return false;
		}
		
		// Publish and subscribe
		int count = 0;
		try
		{
			myRtiAmb.publishInteractionClass( myInterClassHandle );
			evokeCallbacks( 0.1, 0.2 );
			count = 1;
			myRtiAmb.subscribeInteractionClass( myInterClassHandle );
			evokeCallbacks( 0.1, 0.2 );
		}
		catch( RTIexception ex )
		{
			System.out.println( "RTI Exception: " + ex.getClass().toString() + ex.toString() );
			if( count != 0 )
				System.out.println( "Could not publish" );
			else
				System.out.println( "Could not subscribe" );
			return false;
		}
		
		System.out.println( "Subscribed to interaction class: " + myInterClassName + " with handle: " + myInterClassHandle );
		return true;
    }
	
	public void evokeCallbacks(double min, double max ) throws RTIexception
	{
		myRtiAmb.evokeMultipleCallbacks( 0.1, 0.2 );
	}
	
	public AttributeHandleValueMapFactory getAttributeHandleValueMapFactory() 
	throws 
	FederateNotExecutionMember,
	NotConnected,
	RTIinternalError
	{
		return myRtiAmb.getAttributeHandleValueMapFactory();
	}
	
	public ParameterHandleValueMapFactory getParameterHandleValueMapFactory()
	throws 
	FederateNotExecutionMember,
	NotConnected,
	RTIinternalError
	{
		return myRtiAmb.getParameterHandleValueMapFactory();
	}
	
	public void callQuit()
	{
		myCallQuit = true;
	}
	
	public void callSave()
	{
		myCallSave = true;
	}
	
	public void callRestore()
	{
		myCallRestore = true;
	}
    
	   // KEYBOARD THREAD
	   public static class KeyboardTickThread implements Runnable
		{
		    boolean shouldRun;
			Thread runner;
			rtiSimple4etcFra parent;
			public KeyboardTickThread( rtiSimple4etcFra ourParent ) 
			{
				parent = ourParent;
			}
			
//			public KeyboardTickThread( String threadName ) 
//			{
//				runner = new Thread( this, threadName ); // create the new thread
//				runner.start();
//			}
			
			public void run()
			{
				shouldRun = true;
				while( shouldRun )
				{
					Scanner sc = new Scanner(System.in);
					String keyDown = sc.next();
					if( keyDown.equals("q") || keyDown.equals("Q") )
					{
						parent.callQuit();
						break;
					}
					
					if( keyDown.equals("s") || keyDown.equals("S") )
					{
						parent.callSave();
					}
					
					if( keyDown.equals("r") || keyDown.equals("R") )
					{
						parent.callRestore();
					}
				}
			}
			
			public void stopRunning()
			{
				shouldRun = false;
			}
		}
	
	 /**
     * @param args the command line arguments
     */
	public static void main (String[] args)
	{
        try 
		{
			System.out.println( "-----------------------------------------" );
			System.out.println( "Current System Properties: " );
			System.out.println( System.getProperties().toString() );
			System.out.println( "-----------------------------------------" );
			System.out.println( "" );
			// create the federate
			rtiSimple4etcFra myFederate = new rtiSimple4etcFra();
			keyboard = new KeyboardTickThread( myFederate );
			// Setup the keyboard thread
			keyboardThread = new Thread( keyboard, "keyboardThread" );
			// start the thread
			keyboardThread.start();

			myFederate.myFederateType = args[0];
			myFederate.myFederateName = args[0];
			
			// Connect
			myFederate.connect();
			
			// Create the federation
			myFederate.createFedEx();
			myFederate.evokeCallbacks( 0.1, 0.2 );
			
			// Join the federation
			myFederate.joinFedEx();
			myFederate.evokeCallbacks( 0.1, 0.2 );
			
			System.out.println( "publishsubscribeandregisterobject" );
			// publish, subscribe and register - object
			if( !myFederate.publishSubscribeAndRegisterObject() )
			{
				myFederate.resignAndDestroyFedEx();	
				System.exit( 0 );
			}
			
			System.out.println( "publishandsubscribeinteraction" );
			// publish, subscribe - interaction
			if( !myFederate.publishAndSubscribeInteraction() )
			{
				myFederate.resignAndDestroyFedEx();
				System.exit( 0 );
			}
			
			System.out.println( "next" );
			AttributeHandleValueMapFactory ahvFactory = myFederate.getAttributeHandleValueMapFactory();
			System.out.println( "factory - " + ahvFactory );
			AttributeHandleValueMap attrValues = ahvFactory.create( myFederate.myAttrNameHandleMap.size() );
			
			System.out.println( "size " + myFederate.myAttrNameHandleMap.size() );
			System.out.println( "attrValues " + attrValues );
			System.out.println( "attrsize " + attrValues.size() );

			for( Iterator<String> it = myFederate.myAttrNameHandleMap.keySet().iterator(); it.hasNext(); )
			{
				Object key = it.next();
				AttributeHandle value = (AttributeHandle)myFederate.myAttrNameHandleMap.get( key );
				attrValues.put( value, key.toString().getBytes() );
			}
			
			System.out.println( " the attrval map " + attrValues.size() );
			
			System.out.println( "parameters now... " );
			ParameterHandleValueMapFactory phvFactory = myFederate.getParameterHandleValueMapFactory();
			ParameterHandleValueMap paramValues = phvFactory.create( myFederate.myParamNameHandleMap.size() );
			for( Iterator<String> it = myFederate.myParamNameHandleMap.keySet().iterator(); it.hasNext(); )
			{
				Object key = it.next();
				ParameterHandle value = (ParameterHandle)myFederate.myParamNameHandleMap.get( key );
				paramValues.put( value, key.toString().getBytes() );
			}
						
			System.out.println( "parameters done!" );
			System.out.println( "param map " + paramValues.size() );
			myFederate.evokeCallbacks(0.1, 0.2 );
			int count = 0;
			int nbInter = 3;
			while( true )
			{
				try
				{
					// Update the object
					String theTag = "1516e-" + ( count++ );
					
					//System.out.println( "Bytes: " + theTag.getBytes() );
					myFederate.myRtiAmb.updateAttributeValues( myFederate.myObjectHandle, attrValues, theTag.getBytes() );
					
					// Send an interaction every few passes
					if( ( count % 5 ) == 0 ) 
					{
						System.out.println( "Sending interaction..." );
						myFederate.myRtiAmb.sendInteraction( myFederate.myInterClassHandle, paramValues, theTag.getBytes() );
						
						nbInter--;
						if (nbInter == 0)
							myCallQuit = true;
					}
					
					myFederate.evokeCallbacks( 0.1, 0.5 );
					
					if( myFederate.myFedAmbData.myReceivedInitiateFederateSave )
					{
						System.out.println( "save federate" );
						// Perform save operator
						if( !myFederate.saveFederation( myFederate.myFedAmbData.mySaveLabel, false ) )
						{
							// save failed
							break;
						}
					}
					
					if( myFederate.myFedAmbData.myReceivedFederationRestoreBegun )
					{
						System.out.println( "restore federate" );
						// Perform a restore operator
						if( !myFederate.restoreFederation( myFederate.myFedAmbData.myRestoreLabel, false ) )
						{
							// restore failed
							break;
						}
					}
				}
				catch( Exception ex ) 
				{
					System.out.println( "Caught an exception. ------" + ex.getClass().toString() + " : " + ex.toString() );
					break;
				}
				
				// check the keyboard flags
				if( myCallQuit )
				{
					// call the quit stuff
					break;
				}
				else if( myCallSave )
				{
					// call the save code
					// ...
					String saveLabel = "rtiSimpleSave";
					if ( !myFederate.saveFederation( saveLabel, true ) )
					{
					   // Save failed
					   break;
					}
					
					// reset the flag
					myCallSave = false;
				}
				else if( myCallRestore )
				{
					// call the restore code
					//...
					String savedLabel = "rtiSimpleSave";
					if ( !myFederate.restoreFederation( savedLabel, true ) )
					{
					   // Restore failed
					   break;
					}
					
					myCallRestore = false;
				}
				Thread.sleep(2000);
			}
			// Resign and destroy federation
			myFederate.resignAndDestroyFedEx();

		} 
		catch ( RTIexception ex ) 
		{
			// Kill the keyboard thread
			if( keyboardThread != null )
			{
				keyboard.stopRunning();
				//keyboardThread.stop();
			}
			
			System.out.println( "RTI EXCEPTION:" );
			System.out.println( "Caught: " + ex.getClass().toString() + " : " + ex.toString() );
		} 
		catch ( Exception ex )
		{
			// Kill the keyboard thread
			keyboard.stopRunning();
//			keyboardThread.stop();
			System.out.println( "UNKNOWN EXCEPTION:" );
			System.out.println( "Caught: " + ex.getClass().toString() + " : " + ex.toString() );
		}
    }
	
	public RTIambassador      				myRtiAmb;
	public TalkAmbData        				myFedAmbData;
	public ObjectInstanceHandle 			myObjectHandle;
	public InteractionClassHandle 			myInterClassHandle;
	public HashMap<String, AttributeHandle> myAttrNameHandleMap;
	public HashMap<String, ParameterHandle>	myParamNameHandleMap;
	public FederateAmbassador 				myFedAmb;
	public FederateHandle	   				myFederateHandle;
	public String             				myFederationName;
	public String             				myFddFileName;
	public String             				myFederateType;
	public String			   				myClassName;
	public String			   				myInterClassName;
	public String			   				myFederateName;
	
	// Static variables
	public static boolean					myCallQuit;
	public static boolean					myCallSave;
	public static boolean					myCallRestore;
	
	// Thread
	public static Thread 					keyboardThread;
	public static KeyboardTickThread        keyboard;
	
}
